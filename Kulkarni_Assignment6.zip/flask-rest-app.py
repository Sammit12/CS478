'''
1. REST API:
REST stands for REpresentational State Transfer.
Client => Request 
Server => Reponse

2. REST Request:
Endpoint: It is the location that the API can use to access the Resources. In this example, http://localhost:5000 is the endpoint.
Methods: Different requests the client can send to the server. 
	   Important methods are GET, PUT, POST,  DELETE. 
           GET is like a read. It requests data from various resources.
           PUT, and POST requests are for inserting or updating a resource.
Header: Contains the information that the client can send to the server and also the information the client will accept from the server. Information like authentication, encoding details, etc. 
        Header information is in property-value pairs.
Body: Contains the information that the client wants to send to the server.

3. Response Status codes
1XX -Informational: Client should continue with their request
2XX -Success: Indicates the client request was accepted successfully. The status code of 200 indicates that the action requested by the client was carried out successfully.
3XX -Redirection: Indicates further action needs to be taken. 301 indicates that the API was assigned a new permanent URI.
4XX -Client Error: Indicates to the client that an error has occurred. 404 indicates to the client that the requested resource is currently not found but may be available in the future.
5XX - Server Error: Indicates server is aware that the request has errored or is incapable of performing the request


4.Idempotent Methods 
An idempotent HTTP method is an HTTP method that can be called many times without different outcomes. It would not matter if the method is called only once, or ten times over. The result should be the same.
GET, PUT, DELETE - Idempotent
POST - Not Idempotent


5. This Demo Application prerequsites:
pip install flask-restful
pip install flask


5. Flask
https://flask.palletsprojects.com/en/1.1.x/ 

6. Server
Start:
python flask-rest-app.py

6. Client - Postman
Download from https://www.postman.com/downloads/
Start:
Postman application

'''


from flask import Flask, jsonify, request
import pandas as pd
import tensorflow as tf
import keras
from keras.models import load_model
# initialize our Flask application
def auc(y_true, y_pred):
    auc = tf.metrics.auc(y_true, y_pred)[1]
    keras.backend.get_session().run(tf.local_variables_initializer())
    return auc


model = load_model('model.h5', custom_objects={'auc': auc})
app= Flask(__name__)
@app.route("/name", methods=["POST"])
def setName():
    if request.method=='POST':
        posted_data = request.get_json()
        data = posted_data['data']
        return jsonify(str("Successfully stored  " + str(data)))

@app.route("/message", methods=["GET"])
def message():
    posted_data = request.get_json()
    name = posted_data['name']
    return jsonify(" Hope you are having a good time " +  name + "!!!")

@app.route("/hello", methods=["GET"])
def hello():
    return "<HTTML> <BODY> <STRONG> Sammit Kulkarni </STRONG> 29 April 2022  The image you’ve submitted is classified as a:  rock</BODY> </HTML>"

#  main thread of execution to start the server
if __name__=='__main__':
    app.run(debug=True)
    